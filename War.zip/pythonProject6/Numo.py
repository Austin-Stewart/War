import random, models, functions

pot = [2, 2, 2, 2, 3, 3, 3, 3, 4, 4, 4, 4, 5, 5, 5, 5, 6, 6, 6, 6, 7, 7, 7, 7, 8, 8, 8, 8, 9, 9, 9, 9, 10,
       10, 10, 10, 11, 11, 11, 11, 12, 12, 12, 12, 13, 13, 13, 13, 14, 14, 14, 14]
shuffled_deck = []
player_1 = models.Player()
player_2 = models.Player()
deck = functions.shuffle_deck(pot, shuffled_deck)


def dispense_deck(one, two):
    x = 0
    while len(player_1.deck) != 26:
        player_1.deck.append(shuffled_deck[x])
        x += 1
        if len(player_2.deck) < 26:
            player_2.deck.append(shuffled_deck[x + 1])
    return player_1.deck, player_2.deck


def play(decks):
    x = 0
    while x < 26:
        print("Player_1 played: " + functions.name_of_card(player_1.deck, player_2.deck, x)[0] + " Player_2 played: " +
              functions.name_of_card(player_1.deck, player_2.deck, x)[1])
        if player_1.deck[x] > player_2.deck[x]:
            player_1.points += 1
        elif player_1.deck[x] < player_2.deck[x]:
            player_2.points += 1
        x += 1
    if player_2.points > player_1.points:
        print("Player 2 wins the game")
    else:
        print("Player 1 wins the game")


play(dispense_deck(player_1, player_2))
print("Player 1 points: ", player_1.points)
print("Player 2 points: ", player_2.points)
