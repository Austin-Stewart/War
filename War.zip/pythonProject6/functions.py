import random


def shuffle_deck(universal_set, shuffled_deck):  # Shuffles deck and returns it
    while len(universal_set) > 0:
        try:
            random_1 = random.randint(0, len(universal_set) - 1)
            shuffled_deck.append(universal_set[random_1])
            universal_set.remove(universal_set[random_1])
        except IndexError:
            print("Pot is too small")
            return shuffled_deck


def disperse_decks(shuffled_deck, player_1, player_2):
    for i in shuffled_deck:
        while len(player_1.deck) != 26:
            player_1.deck.append(shuffled_deck[i])
            shuffled_deck.remove(shuffled_deck[i])
            if len(shuffled_deck) != 0:
                player_2.deck.append(shuffled_deck[i])
                shuffled_deck.remove(shuffled_deck[i])
            return player_1.deck, player_2.deck


def name_of_card(deck1, deck2, x):
    # Give each card a value
    card_1 = ""
    card_2 = ""
    if deck1[x] == 2:
        card_1 = "Two"
    if deck2[x] == 2:
        card_2 = "Two"
    if deck1[x] == 3:
        card_1 = "Three"
    if deck2[x] == 3:
        card_2 = "Three"
    if deck1[x] == 4:
        card_1 = "Four"
    if deck2[x] == 4:
        card_2 = "Four"
    if deck1[x] == 5:
        card_1 = "Five"
    if deck2[x] == 5:
        card_2 = "Five"
    if deck1[x] == 6:
        card_1 = "Six"
    if deck2[x] == 6:
        card_2 = "Six"
    if deck1[x] == 7:
        card_1 = "Seven"
    if deck2[x] == 7:
        card_2 = "Seven"
    if deck1[x] == 8:
        card_1 = "Eight"
    if deck2[x] == 8:
        card_2 = "Eight"
    if deck1[x] == 9:
        card_1 = "Nine"
    if deck2[x] == 9:
        card_2 = "Nine"
    if deck1[x] == 10:
        card_1 = "Ten"
    if deck2[x] == 10:
        card_2 = "Ten"
    if deck1[x] == 11:
        card_1 = "Jack"
    if deck2[x] == 11:
        card_2 = "Jack"
    if deck1[x] == 12:
        card_1 = "Queen"
    if deck2[x] == 12:
        card_2 = "Queen"
    if deck1[x] == 13:
        card_1 = "King"
    if deck2[x] == 13:
        card_2 = "King"
    if deck1[x] == 14:
        card_1 = "Ace"
    if deck2[x] == 14:
        card_2 = "Ace"
    return card_1, card_2
