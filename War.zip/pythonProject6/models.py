class Player:
    def __init__(self):
        self.name = ""
        self.deck = []
        self.points = 0

    def win(self):
        print(self.name + " wins.")

    def loss(self):
        print(self.name + "loses.")

    def describe_player(self):
        print("Player:" + self.name + "\n" + "Deck" + str(self.deck) + "\n" + "Points:" + str(self.points))

